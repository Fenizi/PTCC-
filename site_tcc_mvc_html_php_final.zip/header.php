<header>
    <nav>
        <a href="pages/home.php">Home</a>
        <a href="pages/clientes.php">Clientes</a>
        <a href="pages/produtos.php">Produtos</a>
        <a href="pages/relatorios.php">Relatórios</a>
        <a href="pages/sobre.php">Sobre</a>
        <a href="pages/contato.php">Contato</a>
        <a href="pages/login.php">Login</a>
    </nav>
</header>