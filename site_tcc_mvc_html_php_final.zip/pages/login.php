
<h1>Login</h1>
<form method='post'>
    <input type='email' name='email' placeholder='E-mail'><br>
    <input type='password' name='senha' placeholder='Senha'><br>
    <button type='submit'>Entrar</button>
</form>
