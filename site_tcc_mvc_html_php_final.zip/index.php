<?php include('header.php'); ?>
<div class='container'>
    <?php include('pages/home.php'); ?>
</div>
<?php include('footer.php'); ?>
