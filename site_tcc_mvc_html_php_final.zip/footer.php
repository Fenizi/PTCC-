<footer>
    <p>&copy; 2025 Sistema de Gestão. Todos os direitos reservados.</p>
</footer>