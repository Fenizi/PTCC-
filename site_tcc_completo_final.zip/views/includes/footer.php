<footer class="bg-dark text-white text-center p-4 mt-5">
<p>© 2025 Sistema GestorX | Projeto TCC</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>