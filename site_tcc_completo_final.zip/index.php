<?php
require_once 'controllers/PageController.php';
$page = $_GET['page'] ?? 'home';
(new PageController())->loadPage($page);
?>