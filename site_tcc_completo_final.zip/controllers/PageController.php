<?php
class PageController {
  public function loadPage($page) {
    $file = "views/pages/{$page}.php";
    include 'views/includes/header.php';
    if (file_exists($file)) include $file;
    else echo '<div class="container mt-5"><h1>Página não encontrada</h1></div>';
    include 'views/includes/footer.php';
  }
}